let countdown;
const timerDisplay = document.getElementById('timer');
const daysDisplay = document.getElementById('days');
const hoursDisplay = document.getElementById('hours');
const minutesDisplay = document.getElementById('minutes');
const secondsDisplay = document.getElementById('seconds');
const startBtn = document.getElementById('start-btn');
const resetBtn = document.getElementById('reset-btn');
const datetimeInput = document.getElementById('datetime-input');
const ringtone = document.getElementById('ringtone'); // Get the audio element

startBtn.addEventListener('click', startCountdown);
resetBtn.addEventListener('click', resetCountdown);

function startCountdown() {
    const targetDate = new Date(datetimeInput.value);
    if (isNaN(targetDate)) {
        alert('Please select a valid date and time.');
        return;
    }

    clearInterval(countdown);
    countdown = setInterval(() => {
        const now = new Date();
        const timeLeft = targetDate - now;

        if (timeLeft <= 0) {
            clearInterval(countdown);
            timerDisplay.innerHTML = '<h2>Time’s Up!</h2>';
            ringtone.play(); // Play the ringtone when time is up
            return;
        }

        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        daysDisplay.innerText = String(days).padStart(2, '0');
        hoursDisplay.innerText = String(hours).padStart(2, '0');
        minutesDisplay.innerText = String(minutes).padStart(2, '0');
        secondsDisplay.innerText = String(seconds).padStart(2, '0');
    }, 1000);
}

function resetCountdown() {
    clearInterval(countdown);
    daysDisplay.innerText = '00';
    hoursDisplay.innerText = '00';
    minutesDisplay.innerText = '00';
    secondsDisplay.innerText = '00';
    datetimeInput.value = '';
}